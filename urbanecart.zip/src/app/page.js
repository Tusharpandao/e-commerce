import Image from "next/image";

export default function Home() {
  return (
  <div>
    <h1 className="text-3xl font-bold underline text-amber-300">
      Welcome to Next.js with Tailwind CSS!
    </h1>

    
  </div>
  );
}
